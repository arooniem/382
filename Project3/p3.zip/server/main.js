import { Meteor } from 'meteor/meteor';

import '../imports/api/http.js';

Meteor.startup(() => {
  // code to run on server at startup
});